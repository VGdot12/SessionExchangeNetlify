"""Student session exchange."""

